package bond.destroyerplayz.rskoth;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class RsKoth extends JavaPlugin {
    private FileConfiguration messages;
    private FileConfiguration koths;
    private File kothsFile;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        saveResourceIfMissing("messages.yml");
        saveResourceIfMissing("koths.yml");
        saveResourceIfMissing("rewards.yml");
        saveResourceIfMissing("menus.yml");
        saveResourceIfMissing("schedule.yml");
        saveResourceIfMissing("settings.yml");
        loadCustomFiles();

        getLogger().info("==================================");
        getLogger().info("RsKoth v" + getDescription().getVersion());
        getLogger().info("Author: DestroyerPlayz");
        getLogger().info("Server: " + getServer().getName() + " / " + getServer().getVersion());
        getLogger().info("Loaded arenas: " + koths.getConfigurationSection("arenas").getKeys(false).size());
        getLogger().info("Scheduling: " + (getConfig().getBoolean("schedule.enabled", false) ? "enabled" : "disabled"));
        getLogger().info("RsKoth initialized.");
        getLogger().info("==================================");
    }

    private void saveResourceIfMissing(String name) {
        File file = new File(getDataFolder(), name);
        if (!file.exists()) saveResource(name, false);
    }

    private void loadCustomFiles() {
        messages = YamlConfiguration.loadConfiguration(new File(getDataFolder(), "messages.yml"));
        kothsFile = new File(getDataFolder(), "koths.yml");
        koths = YamlConfiguration.loadConfiguration(kothsFile);
        if (!koths.isConfigurationSection("arenas")) koths.createSection("arenas");
    }

    private String msg(String key) {
        String raw = messages.getString(key, "&cMissing message: " + key);
        String prefix = messages.getString("prefix", "");
        return color(prefix + raw);
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }

    private void saveKoths() {
        try {
            koths.save(kothsFile);
        } catch (IOException e) {
            getLogger().severe("Could not save koths.yml: " + e.getMessage());
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("koth")) return false;
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            List<String> help = messages.getStringList("help");
            help.forEach(line -> sender.sendMessage(color(line)));
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (sub.equals("reload")) {
            if (!sender.hasPermission("rskoth.admin")) { sender.sendMessage(msg("no-permission")); return true; }
            reloadConfig();
            loadCustomFiles();
            sender.sendMessage(msg("reloaded"));
            return true;
        }
        if (sub.equals("list")) {
            if (!koths.isConfigurationSection("arenas") || koths.getConfigurationSection("arenas").getKeys(false).isEmpty()) {
                sender.sendMessage(color("&eNo arenas have been created."));
            } else {
                sender.sendMessage(color("&6Arenas: &e" + String.join(", ", koths.getConfigurationSection("arenas").getKeys(false))));
            }
            return true;
        }
        if (sub.equals("create") && args.length >= 2) {
            if (!sender.hasPermission("rskoth.admin")) { sender.sendMessage(msg("no-permission")); return true; }
            String arena = args[1].toLowerCase(Locale.ROOT);
            if (koths.contains("arenas." + arena)) { sender.sendMessage(msg("arena-exists")); return true; }
            koths.createSection("arenas." + arena);
            saveKoths();
            sender.sendMessage(color(msg("arena-created").replace("{arena}", arena)));
            return true;
        }
        if (sub.equals("delete") && args.length >= 2) {
            if (!sender.hasPermission("rskoth.admin")) { sender.sendMessage(msg("no-permission")); return true; }
            String arena = args[1].toLowerCase(Locale.ROOT);
            if (!koths.contains("arenas." + arena)) { sender.sendMessage(msg("arena-not-found")); return true; }
            koths.set("arenas." + arena, null);
            saveKoths();
            sender.sendMessage(color(msg("arena-deleted").replace("{arena}", arena)));
            return true;
        }
        if ((sub.equals("setpos1") || sub.equals("setpos2")) && args.length >= 2) {
            if (!sender.hasPermission("rskoth.admin")) { sender.sendMessage(msg("no-permission")); return true; }
            if (!(sender instanceof org.bukkit.entity.Player player)) { sender.sendMessage(msg("player-only")); return true; }
            String arena = args[1].toLowerCase(Locale.ROOT);
            if (!koths.contains("arenas." + arena)) { sender.sendMessage(msg("arena-not-found")); return true; }
            String key = sub.equals("setpos1") ? "pos1" : "pos2";
            var loc = player.getLocation();
            String path = "arenas." + arena + "." + key;
            koths.set(path + ".world", loc.getWorld().getName());
            koths.set(path + ".x", loc.getBlockX());
            koths.set(path + ".y", loc.getBlockY());
            koths.set(path + ".z", loc.getBlockZ());
            saveKoths();
            sender.sendMessage(color("&aSet " + key + " for arena &e" + arena + "&a."));
            return true;
        }
        if (sub.equals("start") && args.length >= 2) {
            if (!sender.hasPermission("rskoth.admin")) { sender.sendMessage(msg("no-permission")); return true; }
            String arena = args[1].toLowerCase(Locale.ROOT);
            if (!koths.contains("arenas." + arena)) { sender.sendMessage(msg("arena-not-found")); return true; }
            if (!koths.contains("arenas." + arena + ".pos1") || !koths.contains("arenas." + arena + ".pos2")) {
                sender.sendMessage(msg("arena-incomplete")); return true;
            }
            sender.sendMessage(color("&eArena configuration validated, but capture event logic is not implemented yet."));
            return true;
        }
        if (sub.equals("stop")) {
            if (!sender.hasPermission("rskoth.admin")) { sender.sendMessage(msg("no-permission")); return true; }
            sender.sendMessage(color("&eNo active capture event is implemented in this starter build."));
            return true;
        }
        sender.sendMessage(msg("unknown-command"));
        return true;
    }
}
